import { BookOpen, Code, Briefcase, FlaskConical, Palette, Stethoscope, Scale, Laptop } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export function Courses() {
  const programs = [
    {
      icon: Code,
      title: 'Computer Science',
      level: 'Undergraduate & Graduate',
      duration: '4 years / 2 years',
      description: 'Learn programming, algorithms, AI, and software development from industry experts.',
    },
    {
      icon: Briefcase,
      title: 'Business Administration',
      level: 'Undergraduate & MBA',
      duration: '4 years / 2 years',
      description: 'Develop leadership skills and business acumen for the global marketplace.',
    },
    {
      icon: FlaskConical,
      title: 'Engineering',
      level: 'Undergraduate & Graduate',
      duration: '4 years / 2 years',
      description: 'Master mechanical, electrical, and civil engineering principles.',
    },
    {
      icon: Stethoscope,
      title: 'Health Sciences',
      level: 'Undergraduate & Graduate',
      duration: '4 years / 2 years',
      description: 'Prepare for careers in healthcare, nursing, and medical research.',
    },
    {
      icon: Palette,
      title: 'Arts & Design',
      level: 'Undergraduate & Graduate',
      duration: '4 years / 2 years',
      description: 'Explore creativity through visual arts, graphic design, and digital media.',
    },
    {
      icon: Scale,
      title: 'Law',
      level: 'Graduate',
      duration: '3 years',
      description: 'Study legal theory, practice, and ethics to become a skilled attorney.',
    },
    {
      icon: BookOpen,
      title: 'Liberal Arts',
      level: 'Undergraduate',
      duration: '4 years',
      description: 'Gain broad knowledge in humanities, social sciences, and natural sciences.',
    },
    {
      icon: Laptop,
      title: 'Data Science',
      level: 'Graduate',
      duration: '2 years',
      description: 'Master data analytics, machine learning, and statistical modeling.',
    },
  ];

  const features = [
    'Hands-on learning with industry projects',
    'Expert faculty with real-world experience',
    'Modern facilities and cutting-edge technology',
    'Internship and career placement support',
    'Flexible online and hybrid options',
    'Study abroad opportunities',
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[400px] flex items-center justify-center text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 to-blue-700/90 z-10"></div>
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1606761568499-6d2451b23c66?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwY2xhc3Nyb29tJTIwbGVjdHVyZSUyMHN0dWRlbnRzfGVufDF8fHx8MTc3MDI2OTcxN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Classroom"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="relative z-20 max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Our Programs</h1>
          <p className="text-xl">Discover world-class programs designed for your success</p>
        </div>
      </section>

      {/* Programs Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Academic Programs</h2>
            <p className="text-xl text-gray-600">Choose from over 150 undergraduate and graduate programs</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {programs.map((program, index) => {
              const Icon = program.icon;
              return (
                <div key={index} className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow border border-gray-200">
                  <div className="flex items-center justify-center w-14 h-14 bg-blue-100 rounded-lg mb-4">
                    <Icon className="w-7 h-7 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{program.title}</h3>
                  <div className="text-sm text-blue-600 font-medium mb-1">{program.level}</div>
                  <div className="text-sm text-gray-500 mb-3">{program.duration}</div>
                  <p className="text-gray-600">{program.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Why Our Programs Stand Out</h2>
              <p className="text-lg text-gray-600 mb-6">
                Our academic programs are designed to provide you with the knowledge, skills, 
                and experiences needed to excel in your chosen field. We combine rigorous 
                academics with practical application to ensure you're career-ready upon graduation.
              </p>
              <ul className="space-y-3">
                {features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                    </div>
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-blue-600 text-white p-6 rounded-lg">
                <div className="text-4xl font-bold mb-2">150+</div>
                <div>Programs Offered</div>
              </div>
              <div className="bg-green-600 text-white p-6 rounded-lg">
                <div className="text-4xl font-bold mb-2">95%</div>
                <div>Job Placement Rate</div>
              </div>
              <div className="bg-purple-600 text-white p-6 rounded-lg">
                <div className="text-4xl font-bold mb-2">20:1</div>
                <div>Student-Faculty Ratio</div>
              </div>
              <div className="bg-orange-600 text-white p-6 rounded-lg">
                <div className="text-4xl font-bold mb-2">40+</div>
                <div>Research Centers</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Program Levels */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Program Levels</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Undergraduate</h3>
              <p className="text-gray-600 mb-4">
                Bachelor's degree programs that provide a solid foundation in your chosen field.
              </p>
              <div className="text-3xl font-bold text-blue-600">4 Years</div>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Graduate</h3>
              <p className="text-gray-600 mb-4">
                Master's programs for advanced study and specialized expertise.
              </p>
              <div className="text-3xl font-bold text-blue-600">1-2 Years</div>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Doctoral</h3>
              <p className="text-gray-600 mb-4">
                PhD programs for research and academic leadership.
              </p>
              <div className="text-3xl font-bold text-blue-600">3-5 Years</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
