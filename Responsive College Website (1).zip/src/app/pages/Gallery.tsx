import { useState } from 'react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export function Gallery() {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = ['all', 'campus', 'facilities', 'events', 'student-life'];

  const galleryItems = [
    {
      id: 1,
      image: 'https://images.unsplash.com/photo-1741528803484-a14f1ae76f2e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwY2FtcHVzJTIwc3R1ZGVudHMlMjB3YWxraW5nfGVufDF8fHx8MTc3MDIzNDk3OHww&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'Main Campus',
      category: 'campus',
    },
    {
      id: 2,
      image: 'https://images.unsplash.com/photo-1722248540590-ba8b7af1d7b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwbGlicmFyeSUyMHN0dWRlbnRzJTIwc3R1ZHlpbmd8ZW58MXx8fHwxNzcwMjY5Njg1fDA&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'University Library',
      category: 'facilities',
    },
    {
      id: 3,
      image: 'https://images.unsplash.com/photo-1679653226697-2b0fbf7c17f7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwYnVpbGRpbmclMjBhcmNoaXRlY3R1cmUlMjBtb2Rlcm58ZW58MXx8fHwxNzcwMjM0NzAxfDA&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'Modern Architecture',
      category: 'campus',
    },
    {
      id: 4,
      image: 'https://images.unsplash.com/photo-1606761568499-6d2451b23c66?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwY2xhc3Nyb29tJTIwbGVjdHVyZSUyMHN0dWRlbnRzfGVufDF8fHx8MTc3MDI2OTcxN3ww&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'Lecture Hall',
      category: 'facilities',
    },
    {
      id: 5,
      image: 'https://images.unsplash.com/photo-1738949538943-e54722a44ffc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwZ3JhZHVhdGlvbiUyMGNlcmVtb255fGVufDF8fHx8MTc3MDE4NzY4MHww&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'Graduation Ceremony',
      category: 'events',
    },
    {
      id: 6,
      image: 'https://images.unsplash.com/photo-1762709753300-342ab94e8b05?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwc3BvcnRzJTIwZmllbGQlMjBhdGhsZXRpY3xlbnwxfHx8fDE3NzAyNjk4Mzd8MA&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'Athletic Facilities',
      category: 'facilities',
    },
    {
      id: 7,
      image: 'https://images.unsplash.com/photo-1612773085209-476549690cd7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwc2NpZW5jZSUyMGxhYm9yYXRvcnklMjByZXNlYXJjaHxlbnwxfHx8fDE3NzAxOTA0OTJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'Science Laboratory',
      category: 'facilities',
    },
    {
      id: 8,
      image: 'https://images.unsplash.com/photo-1687709645238-0470ff08a6bf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwY2FmZXRlcmlhJTIwc3R1ZGVudHMlMjBkaW5pbmd8ZW58MXx8fHwxNzcwMjY5ODM4fDA&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'Student Dining',
      category: 'student-life',
    },
    {
      id: 9,
      image: 'https://images.unsplash.com/photo-1761245591926-6117489d5ce1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwZG9ybWl0b3J5JTIwc3R1ZGVudCUyMGhvdXNpbmd8ZW58MXx8fHwxNzcwMjY5ODM4fDA&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'Student Housing',
      category: 'student-life',
    },
    {
      id: 10,
      image: 'https://images.unsplash.com/photo-1760121788536-9797394e210e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwYXVkaXRvcml1bSUyMGxlY3R1cmUlMjBoYWxsfGVufDF8fHx8MTc3MDI2OTgzOHww&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'Auditorium',
      category: 'facilities',
    },
    {
      id: 11,
      image: 'https://images.unsplash.com/photo-1731834453355-df041245e7d7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwY29tcHV0ZXIlMjBsYWIlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc3MDI2OTgzOXww&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'Computer Lab',
      category: 'facilities',
    },
    {
      id: 12,
      image: 'https://images.unsplash.com/photo-1758685734511-4f49ce9a382b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzb3IlMjB0ZWFjaGVyJTIwdW5pdmVyc2l0eXxlbnwxfHx8fDE3NzAyNjk3MTh8MA&ixlib=rb-4.1.0&q=80&w=1080',
      title: 'Faculty Research',
      category: 'events',
    },
  ];

  const filteredItems = selectedCategory === 'all' 
    ? galleryItems 
    : galleryItems.filter(item => item.category === selectedCategory);

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-blue-700 text-white py-20">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Photo Gallery</h1>
          <p className="text-xl">Explore life at Excellence University through our lens</p>
        </div>
      </section>

      {/* Filter Buttons */}
      <section className="py-8 bg-gray-50 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-3 justify-center">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-2 rounded-full font-medium transition-colors ${
                  selectedCategory === category
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-300'
                }`}
              >
                {category.charAt(0).toUpperCase() + category.slice(1).replace('-', ' ')}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => (
              <div 
                key={item.id} 
                className="group relative overflow-hidden rounded-lg shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer"
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <ImageWithFallback
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                  <div className="p-4 text-white w-full">
                    <h3 className="text-lg font-semibold">{item.title}</h3>
                    <p className="text-sm text-gray-200 capitalize">{item.category.replace('-', ' ')}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredItems.length === 0 && (
            <div className="text-center py-12">
              <p className="text-xl text-gray-500">No images found in this category.</p>
            </div>
          )}
        </div>
      </section>

      {/* Virtual Tour CTA */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Experience Our Campus Virtually</h2>
          <p className="text-xl mb-8">
            Take a 360° virtual tour of our beautiful campus from the comfort of your home
          </p>
          <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
            Start Virtual Tour
          </button>
        </div>
      </section>
    </div>
  );
}
