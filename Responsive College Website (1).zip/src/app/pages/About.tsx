import { Target, Eye, Award, Users, BookOpen, Globe } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export function About() {
  const values = [
    { icon: Target, title: 'Excellence', description: 'Pursuing the highest standards in education and research' },
    { icon: Users, title: 'Diversity', description: 'Embracing diverse perspectives and inclusive community' },
    { icon: BookOpen, title: 'Innovation', description: 'Fostering creativity and cutting-edge thinking' },
    { icon: Globe, title: 'Impact', description: 'Creating positive change in society and the world' },
  ];

  const milestones = [
    { year: '1950', event: 'University Founded' },
    { year: '1975', event: 'First Research Center Established' },
    { year: '2000', event: 'Global Campus Network Launched' },
    { year: '2020', event: 'Reached 15,000+ Students' },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[400px] flex items-center justify-center text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 to-blue-700/90 z-10"></div>
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1679653226697-2b0fbf7c17f7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwYnVpbGRpbmclMjBhcmNoaXRlY3R1cmUlMjBtb2Rlcm58ZW58MXx8fHwxNzcwMjM0NzAxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="University Building"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="relative z-20 max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">About Us</h1>
          <p className="text-xl">Discover our rich history and commitment to excellence</p>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="bg-blue-50 p-8 rounded-lg">
              <div className="flex items-center gap-3 mb-4">
                <Target className="w-10 h-10 text-blue-600" />
                <h2 className="text-3xl font-bold text-gray-900">Our Mission</h2>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed">
                To provide transformative education that empowers students to become leaders, 
                innovators, and responsible global citizens. We are committed to fostering 
                intellectual curiosity, critical thinking, and a lifelong passion for learning.
              </p>
            </div>
            <div className="bg-blue-50 p-8 rounded-lg">
              <div className="flex items-center gap-3 mb-4">
                <Eye className="w-10 h-10 text-blue-600" />
                <h2 className="text-3xl font-bold text-gray-900">Our Vision</h2>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed">
                To be a globally recognized institution of higher learning that shapes the future 
                through groundbreaking research, innovative teaching, and meaningful community 
                engagement that addresses the world's most pressing challenges.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* History */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our History</h2>
            <p className="text-xl text-gray-600">Over seven decades of academic excellence</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {milestones.map((milestone, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-blue-600 mb-3">{milestone.year}</div>
                <p className="text-gray-700">{milestone.event}</p>
              </div>
            ))}
          </div>
          <div className="mt-12 bg-white p-8 rounded-lg shadow-md">
            <p className="text-lg text-gray-700 leading-relaxed">
              Founded in 1950, Excellence University began with a vision to make quality education 
              accessible to all. Over the decades, we've grown from a small college with 200 students 
              to a major research university with over 15,000 students from 80 countries. Our journey 
              has been marked by continuous innovation, expanding academic programs, and a steadfast 
              commitment to academic excellence and social responsibility.
            </p>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Core Values</h2>
            <p className="text-xl text-gray-600">The principles that guide everything we do</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <div key={index} className="text-center p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                    <Icon className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{value.title}</h3>
                  <p className="text-gray-600">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Accreditation */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <Award className="w-16 h-16 mx-auto mb-6" />
          <h2 className="text-4xl font-bold mb-4">Accreditation & Recognition</h2>
          <p className="text-xl leading-relaxed">
            Excellence University is accredited by major national and international accrediting bodies. 
            Our programs meet the highest standards of quality and are recognized worldwide. We are 
            proud members of leading educational associations and consistently ranked among the top 
            universities globally.
          </p>
        </div>
      </section>
    </div>
  );
}
