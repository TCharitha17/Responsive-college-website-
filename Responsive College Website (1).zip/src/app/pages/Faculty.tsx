import { GraduationCap, Award, BookOpen, Globe } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export function Faculty() {
  const facultyMembers = [
    {
      name: 'Dr. Sarah Johnson',
      title: 'Professor of Computer Science',
      department: 'Computer Science',
      education: 'PhD, MIT',
      specialization: 'Artificial Intelligence & Machine Learning',
    },
    {
      name: 'Dr. Michael Chen',
      title: 'Professor of Business',
      department: 'Business Administration',
      education: 'PhD, Harvard',
      specialization: 'Strategic Management & Leadership',
    },
    {
      name: 'Dr. Emily Rodriguez',
      title: 'Associate Professor of Engineering',
      department: 'Engineering',
      education: 'PhD, Stanford',
      specialization: 'Renewable Energy Systems',
    },
    {
      name: 'Dr. James Williams',
      title: 'Professor of Medicine',
      department: 'Health Sciences',
      education: 'MD, PhD, Johns Hopkins',
      specialization: 'Cardiovascular Research',
    },
    {
      name: 'Dr. Maria Garcia',
      title: 'Professor of Arts',
      department: 'Arts & Design',
      education: 'MFA, Yale',
      specialization: 'Contemporary Art & Digital Media',
    },
    {
      name: 'Dr. David Thompson',
      title: 'Professor of Law',
      department: 'Law',
      education: 'JD, Columbia',
      specialization: 'International Law & Human Rights',
    },
    {
      name: 'Dr. Lisa Anderson',
      title: 'Professor of Liberal Arts',
      department: 'Liberal Arts',
      education: 'PhD, Princeton',
      specialization: 'Philosophy & Ethics',
    },
    {
      name: 'Dr. Robert Kim',
      title: 'Associate Professor of Data Science',
      department: 'Data Science',
      education: 'PhD, Berkeley',
      specialization: 'Statistical Modeling & Analytics',
    },
  ];

  const stats = [
    { value: '500+', label: 'Faculty Members' },
    { value: '92%', label: 'Hold Terminal Degrees' },
    { value: '15:1', label: 'Student-Faculty Ratio' },
    { value: '200+', label: 'Research Publications/Year' },
  ];

  const achievements = [
    {
      icon: Award,
      title: 'Award-Winning Scholars',
      description: 'Our faculty have received numerous prestigious awards and honors in their fields.',
    },
    {
      icon: BookOpen,
      title: 'Published Researchers',
      description: 'Active contributors to leading academic journals and conferences worldwide.',
    },
    {
      icon: Globe,
      title: 'Global Leaders',
      description: 'Internationally recognized experts consulted by governments and organizations.',
    },
    {
      icon: GraduationCap,
      title: 'Dedicated Mentors',
      description: 'Committed to student success through personalized guidance and support.',
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[400px] flex items-center justify-center text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 to-blue-700/90 z-10"></div>
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1758685734511-4f49ce9a382b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzb3IlMjB0ZWFjaGVyJTIwdW5pdmVyc2l0eXxlbnwxfHx8fDE3NzAyNjk3MTh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Professor"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="relative z-20 max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Our Faculty</h1>
          <p className="text-xl">Learn from world-class scholars and industry experts</p>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-blue-600 mb-2">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Faculty Excellence */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Faculty Excellence</h2>
            <p className="text-xl text-gray-600">Our faculty are leaders in teaching, research, and service</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => {
              const Icon = achievement.icon;
              return (
                <div key={index} className="text-center p-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
                    <Icon className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{achievement.title}</h3>
                  <p className="text-gray-600">{achievement.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Faculty Directory */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Meet Our Faculty</h2>
            <p className="text-xl text-gray-600">Distinguished scholars dedicated to your success</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {facultyMembers.map((faculty, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full mx-auto mb-4 flex items-center justify-center text-white text-2xl font-bold">
                  {faculty.name.split(' ').map(n => n[0]).join('')}
                </div>
                <h3 className="text-lg font-semibold text-gray-900 text-center mb-1">{faculty.name}</h3>
                <p className="text-sm text-blue-600 text-center mb-2">{faculty.title}</p>
                <div className="border-t border-gray-200 pt-3 mt-3 space-y-2 text-sm">
                  <div>
                    <span className="text-gray-500">Department:</span>
                    <p className="text-gray-900">{faculty.department}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Education:</span>
                    <p className="text-gray-900">{faculty.education}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Specialization:</span>
                    <p className="text-gray-900">{faculty.specialization}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Join Our Faculty */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Join Our Faculty</h2>
          <p className="text-xl mb-8">
            We're always looking for talented educators and researchers to join our community. 
            Explore current faculty positions and become part of our mission to shape the future.
          </p>
          <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
            View Open Positions
          </button>
        </div>
      </section>
    </div>
  );
}
