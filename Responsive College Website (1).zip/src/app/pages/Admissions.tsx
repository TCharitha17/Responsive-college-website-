import { Calendar, FileText, DollarSign, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { Link } from 'react-router';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export function Admissions() {
  const steps = [
    {
      icon: FileText,
      title: 'Submit Application',
      description: 'Complete the online application form with your personal and academic information.',
    },
    {
      icon: FileText,
      title: 'Submit Documents',
      description: 'Upload transcripts, test scores, letters of recommendation, and personal statement.',
    },
    {
      icon: Clock,
      title: 'Application Review',
      description: 'Our admissions team carefully reviews your application and supporting materials.',
    },
    {
      icon: CheckCircle,
      title: 'Receive Decision',
      description: 'Get your admission decision via email and student portal.',
    },
  ];

  const requirements = [
    'Completed application form',
    'Official high school transcripts',
    'SAT/ACT scores (for undergraduate)',
    'Letters of recommendation (2-3)',
    'Personal statement or essay',
    'Application fee ($75)',
  ];

  const deadlines = [
    { term: 'Fall Semester', earlyDecision: 'November 1, 2025', regularDecision: 'January 15, 2026' },
    { term: 'Spring Semester', earlyDecision: 'N/A', regularDecision: 'October 1, 2025' },
  ];

  const financialAid = [
    { type: 'Merit Scholarships', description: 'Based on academic achievement and test scores' },
    { type: 'Need-Based Aid', description: 'Financial assistance based on demonstrated need' },
    { type: 'Athletic Scholarships', description: 'For outstanding student-athletes' },
    { type: 'Work-Study Programs', description: 'Part-time employment opportunities on campus' },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[400px] flex items-center justify-center text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 to-blue-700/90 z-10"></div>
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1738949538943-e54722a44ffc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwZ3JhZHVhdGlvbiUyMGNlcmVtb255fGVufDF8fHx8MTc3MDE4NzY4MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Graduation"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="relative z-20 max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Admissions</h1>
          <p className="text-xl">Start your journey to excellence today</p>
        </div>
      </section>

      {/* Application Process */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Application Process</h2>
            <p className="text-xl text-gray-600">Four simple steps to join our community</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={index} className="text-center">
                  <div className="relative mb-6">
                    <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto">
                      <Icon className="w-10 h-10 text-white" />
                    </div>
                    <div className="absolute -top-2 -right-2 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold">
                      {index + 1}
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h3>
                  <p className="text-gray-600">{step.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Requirements & Deadlines */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Requirements */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Admission Requirements</h2>
              <div className="bg-white p-8 rounded-lg shadow-md">
                <ul className="space-y-4">
                  {requirements.map((req, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{req}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-6 p-4 bg-blue-50 rounded-lg flex items-start gap-3">
                  <AlertCircle className="w-6 h-6 text-blue-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-gray-700">
                    International students may need to submit TOEFL/IELTS scores and additional documentation.
                  </p>
                </div>
              </div>
            </div>

            {/* Deadlines */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Application Deadlines</h2>
              <div className="space-y-6">
                {deadlines.map((deadline, index) => (
                  <div key={index} className="bg-white p-6 rounded-lg shadow-md">
                    <div className="flex items-center gap-3 mb-4">
                      <Calendar className="w-6 h-6 text-blue-600" />
                      <h3 className="text-xl font-semibold text-gray-900">{deadline.term}</h3>
                    </div>
                    <div className="space-y-2">
                      {deadline.earlyDecision !== 'N/A' && (
                        <div className="flex justify-between">
                          <span className="text-gray-600">Early Decision:</span>
                          <span className="font-semibold text-gray-900">{deadline.earlyDecision}</span>
                        </div>
                      )}
                      <div className="flex justify-between">
                        <span className="text-gray-600">Regular Decision:</span>
                        <span className="font-semibold text-gray-900">{deadline.regularDecision}</span>
                      </div>
                    </div>
                  </div>
                ))}
                <div className="bg-blue-600 text-white p-6 rounded-lg text-center">
                  <p className="text-lg font-semibold mb-2">Ready to Apply?</p>
                  <button className="bg-white text-blue-600 px-6 py-2 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
                    Start Application
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Financial Aid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <DollarSign className="w-12 h-12 text-blue-600 mx-auto mb-4" />
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Financial Aid & Scholarships</h2>
            <p className="text-xl text-gray-600">We're committed to making education affordable and accessible</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {financialAid.map((aid, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md border-l-4 border-blue-600">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{aid.type}</h3>
                <p className="text-gray-600">{aid.description}</p>
              </div>
            ))}
          </div>
          <div className="mt-8 bg-green-50 p-8 rounded-lg text-center">
            <p className="text-lg text-gray-700 mb-4">
              <span className="font-bold">85%</span> of our students receive some form of financial assistance. 
              Average scholarship award: <span className="font-bold">$15,000</span> per year.
            </p>
            <Link to="/contact" className="text-blue-600 hover:text-blue-700 font-semibold">
              Contact Financial Aid Office →
            </Link>
          </div>
        </div>
      </section>

      {/* Campus Tours */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Schedule a Campus Visit</h2>
          <p className="text-xl mb-8">
            Experience our campus firsthand! Join us for a guided tour and information session.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
              Schedule Virtual Tour
            </button>
            <button className="bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-800 transition-colors border-2 border-white">
              Schedule In-Person Visit
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
