
  # Responsive College Website

  This is a code bundle for Responsive College Website. The original project is available at https://www.figma.com/design/cad8oyVSNW4B8Ixag3AV3C/Responsive-College-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  